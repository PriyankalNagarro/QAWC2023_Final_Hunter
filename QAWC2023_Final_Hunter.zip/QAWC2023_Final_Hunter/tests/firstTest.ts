
import { fixture } from "testcafe";
import { Selector } from "testcafe";

//Testcafe doen't support xpath so using css
const home = Selector('a').withText('Home');
const movies = Selector('a').withText('Movies');
const movieName = Selector("h2[data-testid*='title-art'] img");
const availability = Selector("span[data-testid*='entitled-icon'] + span");
const ageSuitability = Selector("span[aria-label*='Suitable for ages'] span");
const serachBoxInput = Selector("input[aria-label='Search Prime Video']");
const firstSerachResult = Selector("div[data-automation-id='navigation-bar-search-suggestions'] li");
const movieImg= Selector("div[data-testid='packshot']");
const threeDots = Selector("label[for*='actn-drpdn']");
const watchTrailer = Selector('span').withText('Watch Trailer');
const timeIndicator = Selector("div.atvwebplayersdk-timeindicator-text.fheif50.fiqc9rt.f1s55b4");
const closeVideo = Selector("div.fewcsle.f1yzibwv.atvwebplayersdk-closebutton-wrapper.hide");
const primeVideoLogo = Selector("img[src*='Logo']");
const allInOnePlace = Selector('h1').withText('Your favorite channels all in one place');
const imgOfChannels = Selector("img[class*='DVPAWebWidgetsCustomComponents']");

fixture("First Fixture").page("https://www.google.com/");

test("First test", async t => {
    //Step 1
     await t.navigateTo("https://www.primevideo.com/");
     await t.maximizeWindow();
     //Step 2
     await t.hover(home);
     await t.click(movies);
     const size = await movieName.count;
     await console.log("Total number of movies are" + size);
     //Step 3
     for(let i=0;i<size;i++){
        await console.log("Movies Name is" + movieName.nth(i).getAttribute("alt"));
         await console.log("Availability of movies" + availability.nth(i).textContent);
        await console.log("Age suitability of movies" + ageSuitability.nth(i).textContent);
     }
     const mainwindow = await t.getCurrentWindow();
     //Step 4 checking whether the links are working fine or not
     for(let i=0;i<size;i++){
       await console.log("Movies link is" + movieName.nth(i).getAttribute("src"));
       const url = await movieName.nth(i).getAttribute("src");
       await t.navigateTo(url!);
     }
     //Navigating back to main page
     await t.switchToWindow(mainwindow);
     await console.log("Currently i am on main window");
     //Step 5
     const moviename = await movieName.nth(4).getAttribute("alt");
     await t.typeText(serachBoxInput,moviename!);
     //Step 6
     await t.expect(firstSerachResult.nth(0).textContent).contains(moviename!);
     //Step 7
     await t.click(firstSerachResult.nth(0)); 
     await t.wait(3000);
     //Step 8
     await t.hover(movieImg);
     await t.click(threeDots);
     await t.click(watchTrailer);
    //Step 9
    await t.pressKey('home right . delete delete delete delete');
    await t.expect(timeIndicator.textContent).eql('00:10');
    await t.pressKey('home right . delete delete delete delete');
    await t.expect(timeIndicator.textContent).eql('00:20');
    await t.pressKey('home right . delete delete delete delete');
    await t.expect(timeIndicator.textContent).eql('00:10');
    await t.pressKey('home left . delete delete delete delete');
    await t.expect(timeIndicator.textContent).eql('00:00');
    //Step 10
    await t.click(closeVideo);
    await t.wait(1000);
    await t.click(primeVideoLogo);
    //Step 11
    await t.scrollIntoView(allInOnePlace);
    //Step 12
    await console.log(imgOfChannels.nth(0).textContent);
    await console.log(imgOfChannels.nth(1).textContent);
    await console.log(imgOfChannels.nth(2).textContent);

});
